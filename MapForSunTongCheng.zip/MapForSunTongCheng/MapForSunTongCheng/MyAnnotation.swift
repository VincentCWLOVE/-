//
//  MyAnnotation.swift
//  MapForSunTongCheng
//
//  Created by vincent on 16/10/24.
//  Copyright © 2016年 Vincent. All rights reserved.
//

import UIKit

import MapKit

class MyAnnotation: NSObject,MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title:String?
    var subtitle: String?
    var image:UIImage?
    
    var preLocation:MKMapPoint?
    var curLocation:MKMapPoint?
//    var location:MKMapPoint {
//        willSet(newLocation){
//            self.curLocation = newLocation
//        }
//        didSet {
//            self.preLocation = oldValue
//            //两点间的距离
//            let distance = MKMetersBetweenMapPoints(self.preLocation!,self.curLocation!)
//            
//        }
//    }
   
    
    init(coordinate:CLLocationCoordinate2D, title:String, subtitle:String){
        self.coordinate = coordinate
        self.title = title
        self.subtitle = subtitle
        
    }
}
