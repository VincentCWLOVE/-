//
//  ViewController.swift
//  MapForSunTongCheng
//
//  Created by vincent on 16/10/24.
//  Copyright © 2016年 Vincent. All rights reserved.
//

import UIKit
import MapKit
import QuartzCore

class ViewController: UIViewController,MKMapViewDelegate {

    var mapView:MKMapView!
    var latitude:Double?
    var longtitude:Double?
    var annotation:MyAnnotation?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.initMapView()
        
        let timer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(ViewController.getDataFromGps), userInfo: nil, repeats: true)
        timer.fire()
        
    }
    
    func initMapView(){
        self.mapView = MKMapView(frame: UIScreen.main.bounds)
        self.mapView.mapType = .standard
        self.mapView.isScrollEnabled = true
        self.mapView.isZoomEnabled = true
        self.mapView.isRotateEnabled = true
        self.mapView.delegate = self
        self.view.addSubview(self.mapView)
        
        self.latitude = 22.55088562
        self.longtitude = 113.9663327
        
        self.setRegionForMap()
        self.addAnnotationToMap()
    
       
    }
    
    func setRegionForMap(){
        let coor:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: self.latitude!, longitude: self.longtitude!)
        let span:MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        let region:MKCoordinateRegion = MKCoordinateRegion(center: coor, span: span)
        self.mapView.setRegion(region, animated: true)
        
    }
    
    func addAnnotationToMap(){
        //添加 annotation
        let coor:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: self.latitude!, longitude: self.longtitude!)
        self.annotation = MyAnnotation(coordinate: coor, title: "我是小车", subtitle: "调试我呀")
        self.annotation?.image = UIImage(named: "map-taxi.png")
        self.mapView.addAnnotation(annotation!)
        
    }
    
 
    
    
    func getDataFromGps() {
        //数值要很小,太大了效果不好
        self.latitude! += 0.00002
        self.longtitude! += 0.00002
        let annotationView = self.mapView(self.mapView, viewFor: self.annotation!)
        self.carMoveAnimation(annotationView: annotationView!)
        
//        return [self.latitude! , self.longtitude!]
        
    }
    
    func carMoveAnimation(annotationView:MKAnnotationView){
        
        let coor:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: self.latitude!, longitude: self.longtitude!)
        let point = MKMapPointForCoordinate(coor)
        
        
        let zoomFactor = self.mapView.visibleMapRect.size.width / Double(self.mapView.bounds.size.width)
        
        let toPos = CGPoint(x: point.x/zoomFactor, y: point.y/zoomFactor)
        
        if MKMapRectContainsPoint(self.mapView.visibleMapRect, point) {
            self.mapView.removeAnnotation(self.annotation!)
            self.addAnnotationToMap()
        }else {
            self.setRegionForMap()
        }
        
        annotationView.center = toPos
        
        
    }
    
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if !(annotation is MyAnnotation) {
            return nil
        }
        
        let reusedID = "test"
        var anView = mapView.dequeueReusableAnnotationView(withIdentifier: reusedID)
        if anView == nil {
            anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reusedID)
            anView?.canShowCallout = true
        }
       
        anView?.image = UIImage(named: "map-taxi.png")
        anView?.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        print("prepare return view")
        return anView
    }
    
    
    
    
    
    
    
    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

